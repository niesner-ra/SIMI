import ij.*;

import ij.process.*;

import ij.measure.*;



import java.awt.*;

import java.awt.event.*;

import java.lang.*; // Assyl included



/**
 * @author Joachim Walter
 *
 */



public class Measure_Mixing_Matrix extends Sync_Measure_3D implements SpectralUnmixing{

	/* Components that "this" plugin is registered to as ...    
	ActionListener:        
	Buttons inherited from Sync_Windows        
	Button bMeasure        
	Button bFirstSlice        
	IntField intFirstSlice        
	Button bLastSlice        
	IntField intLastSlice        
	Button bProjection        
	All Scrollbars in vScrollThresh   

	MouseListener and MouseMotionListener:        
	Selected Windows in list (i.e. their canvasses; inherited from Sync_Windows)        
	ImageCanvas of Projection window (if present)    

	WindowListener:        
	Projection window (if present)	    
	ImageJ main window (inherited from Sync_Windows)
*/    

	protected IntField intNfluors;	
	protected int nFluors;	
	protected int currentFluor;    
	protected MCMResultsTable resultsTable=null;    
	protected MCMResultsWindow resultsWindow=null;	
	protected Label lFluorLabel;   
	protected Button bNextFluor = null, bPrevFluor = null;    
	protected TextFieldFocus textfocFluor = null;	
	protected String[] FluorLabel;    

	/* Quantities to measure for each slice via Statistics class: area,        
	mean value (gives total intensity together with nBins. Don't limit the        
	measurements to thresholded pixels, as the options are used for measuring        
	the background. */  

	protected int mOptions = ImageStatistics.AREA |ImageStatistics.MEAN;    

public Measure_Mixing_Matrix() {        	
	super("Measure Mixing Matrix  "+SpectralUnmixing.VERSIONSTRING);        
    }   

public void run(String args) {    		
	if (super.VERSIONSTRING.compareTo("1.3")<0) {    		
		IJ.error("This plugin requires Sync_Windows version 1.3 or higher.");    		
		return;
    	}        
		super.run(args);
    }

/** Implementation of ActionListener interface. */	

public void actionPerformed(ActionEvent e) {		
	super.actionPerformed(e);	
	if (e.getSource() == bPrevFluor) {			
		currentFluor = (currentFluor==0)?(nFluors):(currentFluor-1);			
		updateFluorDisplay();
		}		
	
	if (e.getSource() == bNextFluor) {			
		currentFluor = (currentFluor==nFluors)?(0):(currentFluor+1);			
		updateFluorDisplay();
		}		

	if (e.getSource() == textfocFluor) {			
		if(currentFluor>0 && resultsTable != null) {				
			resultsTable.setFluorName(currentFluor-1, textfocFluor.getText());
			}			
			resultsWindow.updateDataDisplay();
		}
	}   
	
protected Panel controlPanel() {        
	Panel p = super.controlPanel();

// Put button to start / stop Measurements in intermediate Panel that leaves        
// space for the measure controls.       

	measurePanel = new Panel(new BorderLayout(0, 5));        
	Panel measureSetupPanel = new Panel(new BorderLayout(0, 5));		
	measurePanel.add(measureSetupPanel, BorderLayout.NORTH, 0);        
	
	// Button to Start and Stop Measurements        
	
	bMeasure = new Button("Start Measurements");        
	bMeasure.addActionListener(this);        
	measureSetupPanel.add(bMeasure, BorderLayout.WEST, 0);        
	
	// add Int Field to specify No. of fluors.        
	measureSetupPanel.add(new Label("No. of Fluorochromes  ", Label.RIGHT), BorderLayout.CENTER, 0);        
	intNfluors = new IntField(1, 1, 64);        
	measureSetupPanel.add(intNfluors, BorderLayout.EAST, 0);        

	// Add intermediated panel ("measurePanel") at the lowest side of the main panel.
        
	p.add(measurePanel, BorderLayout.SOUTH, 2);
        return p;
    }    

public void startMeasurements() {        

// Update the window list to ensure that all selected windows indeed exist.
        
	updateWindowList();
	if (vwins == null)			
		return;      
	
	nWindows = vwins.size();        
	if (nWindows == 0)			
		return;

	nFluors = intNfluors.getValue();
	if (nFluors > nWindows) {			
		IJ.showMessage("You will measure mixing matrix at the underdetermined condition.");		// Underdetermined case meassage for SIMI 19Jan17 	
		//return;
		}	
	
	if (resultsTable == null) {			
		initResults(nWindows, nFluors);		
		} else if (nWindows != resultsTable.getNChannels() ||					
		
		nFluors != resultsTable.getNFluors()) {			
			boolean disconnect = IJ.showMessageWithCancel("Caution!",				
			"Current results table is not compatible with selected data.\n " +				
			"Disconnect old results table and start a new one?");		

	if (disconnect) {				
		disconnectResults();	
	initResults(nWindows, nFluors);			
		} else {				
		return;
			}
		}
	currentFluor = 0;       
	
	// build the panel with threshold sliders
        
		ScrollPane measureControl = buildMeasureControl();        
		if (measureControl == null)            
		return;        
	
	// Do GUI stuff: add panel with sliders and panel with min/max and projection buttons.
        
	bMeasure.setLabel("Stop Measurements");        
	setControlsEnabled(false);        
	measurePanel.add(measureControl, BorderLayout.CENTER, 1);        
	measurePanel.add(buildCommonControls(), BorderLayout.SOUTH, 2);        
	pack();		
	updateFluorDisplay();        
	
	// Set Flag.
        measuring = true;        
	// Set Threshold in images.
        updateScrollbars();
    }	
	
	/** Removes contact to everything that is not further needed. */
		
	public void stopMeasurements() {		
	super.stopMeasurements();	
	
	// buttons and text field of the fluorochrome selection control
			
	bPrevFluor.removeActionListener(this);		
		bPrevFluor = null;		
		bNextFluor.removeActionListener(this);		
		bNextFluor = null;		
		textfocFluor.removeActionListener(this);		
		textfocFluor = null;	 
	}	

	public boolean isMeasuring() {		
		return measuring;	
		}

/**  Builds the Panel with buttons and textfields for first and last slice and for projection. */
    	
	protected Panel buildCommonControls() {	
	Panel p = super.buildCommonControls();        
	Panel p1 = new Panel(new FlowLayout(FlowLayout.LEFT, 1, 1));        
	Panel p2 = new Panel(new GridLayout(2,1));		
		lFluorLabel = new Label("Fluor xx");		
		p1.add(lFluorLabel);		
		bPrevFluor = new Button("<");		
		bPrevFluor.addActionListener(this);		
		p1.add(bPrevFluor);		
		bNextFluor = new Button(">");		
		bNextFluor.addActionListener(this);		
		p1.add(bNextFluor);		
		textfocFluor = new TextFieldFocus(15);		
		textfocFluor.addActionListener(this);		
		p1.add(textfocFluor);		
		p2.add(p1);		
		p2.add(new Label("Double-click into ROI in image with segmented reference object!"));        
		p.add(p2, BorderLayout.SOUTH);        
		return p;
    }

/** Repaints the "Fluorochrome" line in the common controls */
	
	protected void updateFluorDisplay() {		
		if (lFluorLabel == null || textfocFluor == null) {			
			return;
		}	

	lFluorLabel.setText(FluorLabel[currentFluor]);		
		if (currentFluor == 0) {			
		textfocFluor.setText("Background");			
		textfocFluor.setEnabled(false);		
		} else {	
		if (resultsTable != null) {				
		textfocFluor.setText(resultsTable.getFluorName(currentFluor-1));			
		} else {	
		textfocFluor.setText("");
			}			
		textfocFluor.setEnabled(true);		
	}
	}

/** greys off and on the control elements for adding and removing windows */
    	
	protected void setControlsEnabled(boolean enable) {	
	super.setControlsEnabled(enable);        
	intNfluors.setEnabled(enable);
    } 
    
	public void disconnectResults() {		
	if (resultsWindow != null) {			
	resultsWindow.nullParent();			
	resultsWindow = null;
		}
		
	if (resultsTable != null) {			
	resultsTable = null;
		}
    }     	
    
	protected void initResults(int nChannels, int nFluors) {	
	disconnectResults();		
	resultsTable = new MCMResultsTable(nChannels, nFluors);		
	for (int i=0; i<nChannels; i++) {			
	resultsTable.setChannelName(i, getImageFromVector(i).getTitle());		
	}		
	
	FluorLabel = new String[nFluors+1];		
	FluorLabel[0] = "Backgr.";		
		for (int i=0; i<nFluors; ++i) {			
		FluorLabel[i+1] = "Fluor "+(i+1);		
		}	

	resultsWindow = new MCMResultsWindow(resultsTable, this);    
	}

/** Distributes the measuring work to the measureBackground() and measureFluor() routines. */    
	
	protected void measure(ImagePlus image, int x, int y) {	
	if (currentFluor == 0) {    		
	measureBackground(image);	
	} else {    		
	measureFluor(image);
    	}     
	}

/** Measures the background signal in one image (channel) or all images simultaneously.*/    
    
	protected void measureBackground(ImagePlus image){    	
	int nFirst, nLast;    	
    	// measure one image or all images depending on cursor synchronization		
	if (cCursor.getState()) {			
	nFirst = 0;			
	nLast = nWindows-1;		
	} else {
			// determine number of clicked image in synchronize vector			
	for (nFirst=0; nFirst<nWindows; ++nFirst) {				
	if (image == getImageFromVector(nFirst)) {					
	break;
				}
			}						
	nLast = nFirst;
		}		
	for (int n=nFirst; n<=nLast; n++){			
	ImagePlus imp = getImageFromVector(n);			
	if (imp == null)				
	continue;			
	Calibration cal = imp.getCalibration();	
			// Determine the first and last slice to loop over.
	int currentSlice = imp.getCurrentSlice();			
	int firstSlice = iFirstSlice[n];
	if (firstSlice > imp.getStackSize())				
	firstSlice = imp.getStackSize();
	int lastSlice = iLastSlice[n];	
	if (lastSlice > imp.getStackSize())				
	lastSlice = imp.getStackSize();	
	for (int slice=firstSlice; slice<=lastSlice; ++slice) {				
	imp.setSlice(slice);	
	ImageStatistics stats = imp.getStatistics(mOptions);	
	if (stats == null) {					
	IJ.error("Measurement Error");	
	return;
				}

				// Read results of measurements and check for divide by zero.	
	double mean = stats.mean;				
	if (Double.isInfinite(mean) || Double.isNaN(mean)) {					
	mean = 0;
				}	
	double pixelCount = stats.pixelCount;	
	if (Double.isInfinite(pixelCount) || Double.isNaN(pixelCount)) {	
	pixelCount = 0;
				}				
	resultsTable.addBackgroundMeasure(n, mean, (long)pixelCount);
			}			
	resultsWindow.updateDataDisplay();			
	imp.setSlice(currentSlice);
		}	    
	}

/** Measures the fluorescence signal of a reference object, which is stained with only one 
	* fluorochrome, in all channels.<p>
 * Method:<p> 
	* For each channel the routine computes the mean intensity of all selected pixels and passes 
	* it on the the results table. For determining the selected pixels, only the image "image"  
	* (the image, which received the mouseclick) is considered. All pixels in this image within 
	* the current ROI and above the threshold are "selected". In the other images, the pixels at 
	* the same coordinates are measured. ROIs and thresholds in the other images are not taken into 
	* account.
 */

protected void measureFluor(ImagePlus impRef) {	
	int iRef = getIndexOfImage(impRef);			
	if(iRef<0) return;        
	ImageProcessor ipRef = impRef.getProcessor();		
	int n=0; // counter for image in vector		
	// Determine the first and last slice to loop over and the threshold.	
	int firstSlice = iFirstSlice[iRef];		
	if (firstSlice > impRef.getStackSize())			
	firstSlice = impRef.getStackSize();		
	int lastSlice = iLastSlice[iRef];		
	if (lastSlice > impRef.getStackSize())			
	lastSlice = impRef.getStackSize();	
	double threshold = ipRef.getMinThreshold();		
		
	// Get ImagePlusses, Processors and Calibrations and remember current slice for all windows	
	
	int[] currentSlice = new int[nWindows];		
	ImagePlus[] imageVector = new ImagePlus[nWindows];		
	ImageProcessor[] ipVector = new ImageProcessor[nWindows];		
	float[][] cTable = new float[nWindows][];		
	Calibration cal;		
	for (n=0; n<nWindows; ++n) {	
	imageVector[n] = getImageFromVector(n);			
	if (imageVector[n] == null) {				
	IJ.error("A synchronized window has been closed. Cannot measure.");				
	return;
			}			
	ipVector[n] = imageVector[n].getProcessor();			
	cal = imageVector[n].getCalibration();			
	cTable[n] = cal!=null?cal.getCTable():null;			
	currentSlice[n] = imageVector[n].getCurrentSlice();	
		}			
	
	// Get ROI bounds and Mask		
	
	int x0 = ipRef.getRoi().x;		
	int y0 = ipRef.getRoi().y;		
	int dx = ipRef.getRoi().width;		
	int dy = ipRef.getRoi().height;		
	byte[] mask = ipRef.getMaskArray();		
	
	// prepare for loop over slices/pixels	
		
	int valueRef = 0;		
	int value = 0;		
	boolean nullWindows = false;		
	double[] meanValues = new double[nWindows];	
	//double[] sdValues = new double[nWindows];     // standard deviation   Assyl
	long nPixels = 0;		
	double f1, f2;		
		
	// loop over all slices in all images and average intensities of selected pixels		
	// calculate running mean		
	
	for (int slice=firstSlice; slice<=lastSlice; ++slice) {		
	
	// Set slice	
			
		for (n=0; n<nWindows; ++n) {				
		imageVector[n].setSlice(slice);
			}
			
		// Loop over pixels, test, whether pixel is in ROI and above Threshold	
		
		int mi=0;
			for (int y=y0; y<(y0+dy); ++y) {				
			for (int x=x0; x<(x0+dx); ++x) {					
			if (mask==null || mask[mi++]!=0) {						
				valueRef = ipRef.getPixel(x, y);						
				if (valueRef>=threshold) {							
				nPixels++;							
				f1 = ((double)(nPixels-1))/((double)nPixels);							
				f2 = 1.0/((double)nPixels);
				for (n=0; n<nWindows; ++n) {								
				value = ipVector[n].getPixel(x, y);								
				meanValues[n] = f1*meanValues[n] + 										
				f2*((cTable[n]!=null)?cTable[n][value]:value)+Double.MIN_VALUE;							
				}					}					
				
					}				
				}			
				}	
			
		
		// Add a loop for standard deviation calculation 	Assyl
			/*nPixels=0;
			int ni=0;
			for (int y=y0; y<(y0+dy); ++y) {				
				for (int x=x0; x<(x0+dx); ++x) {					
					if (mask==null || mask[ni++]!=0) {						
						valueRef = ipRef.getPixel(x, y);						
						if (valueRef>=threshold) {							
							nPixels++;							
							f1 = ((double)(nPixels-1))/((double)nPixels);							
							f2 = 1.0/((double)nPixels);
							for (n=0; n<nWindows; ++n) {								
								value = ipVector[n].getPixel(x, y);								
								sdValues[n] = f1*sdValues[n] + 										
										f2*(//(cTable[n]!=null)?cTable[n][value]:
												(value-meanValues[n])*(value-meanValues[n]))+Double.MIN_VALUE;							
							}	
						}					
					}				
				}			
			}*/
			
		}		

	// Set slice back to what it was
		
	for (n=0; n<nWindows; ++n) {			
	imageVector[n].setSlice(currentSlice[n]);
		}		

	// Take a square root from sdValues			Assyl
	/*for (n=0; n<nWindows; ++n) {
		if(sdValues[n]>=0){
			sdValues[n]=Math.sqrt(sdValues[n]);
		}
	}*/
	
	
	// Write results to resultsTable	
	resultsTable.addFluorMeasure(currentFluor-1, meanValues, /*sdValues,*/ nPixels);		
	resultsWindow.updateDataDisplay();
    }
}
