import ij.*;

import java.io.*;
import java.util.*;

import Jama.Matrix;

/** This is a table for storing a Mixing Matrix and associated data 
 * for spectral unmixing.
 */
    public class MCMResultsTable implements SpectralUnmixing
    {
	    private int nChannels;
	    private int nFluors;

	    private String[] sChannelNames;
	    private String[] sFluorNames;
		private double[] dAvgBackground;
		private long[] nBackgroundPixels;
		private double[][] dAvgFluorSignal;
		//private double[][] dAvgFluorStDeviation;  // Assyl standard deviation
		private long[] nFluorPixels;
		private double[][] dMixingMatrix;
		private double[][] dInverseMatrix; // inverse or pseudoinverse of mixing matrix
		
		private boolean matrixValid;
		private boolean inverseValid;
		
		/** Constructs an empty MCMResultsTable for nChannels channels and nFluors fluorochromes. */
		public MCMResultsTable(int nChannels, int nFluors) {
			if(nChannels<=0 || nFluors<=0) {
				throw new IllegalArgumentException("Dimensions of MCMRTab must be >0.");
			}
			/*if (nChannels < nFluors) {
				throw new IllegalArgumentException("nChannels must be greater or equal nFluors.");	
			}*/
			this.nChannels = nChannels;
			this.nFluors = nFluors;
			
			initDataStructures();
			computeMixingMatrix();
		}
		
		/** Creates an MCMResultsTable from a data file */
		public MCMResultsTable(File file) throws FileNotFoundException, IOException {
			if(!file.exists() || !file.isFile())
				throw new FileNotFoundException("channel matrix file not found");

			int nLoadChannels = 0;
			int nLoadFluors = 0;
			// Read nChannels and nFluors of data file and check for consistency.				
			BufferedReader br = null;
			StringTokenizer tok = null;
			String str = null, tag = null;
			try {
				br = new BufferedReader(new FileReader(file));
				while(true) {
					str = br.readLine();
					if (str==null) break;				
					try {						
						tok = new StringTokenizer(str, "\t", false);
						tag = tok.nextToken();
  						
						if (tag.equals(TAG_N_CHANNELS))
							nLoadChannels = Integer.parseInt(tok.nextToken());
						else if (tag.equals(TAG_N_FLUORS))
							nLoadFluors = Integer.parseInt(tok.nextToken());
							
					} catch (NoSuchElementException e){
					}
				}
				br.close();
			}
			catch (IOException e) {
				throw new IOException("Error in loading MixingMatrix: "+e.getMessage());
			}
			if (nLoadChannels <= 0 || nLoadFluors <= 0 || nLoadChannels < nLoadFluors) {
				throw new IOException("Error in loading MixingMatrix: Invalid dimensions.");
			}	

			nChannels = nLoadChannels;
			nFluors = nLoadFluors;	
			
			initDataStructures();
			computeMixingMatrix();

			loadFile(file.getAbsolutePath(), false);				
		}


		public void clear() {
			for (int i=0; i<nChannels; ++i) {
				dAvgBackground[i] = 0;
				nBackgroundPixels[i] = 0;
			}
			for (int j=0; j<nFluors; ++j) {
				for (int i=0; i<nChannels; ++i) {
					dAvgFluorSignal[i][j] = 0;
				}
				
				nFluorPixels[j] = 0;
			}
			/*for (int j=0; j<nFluors; ++j) {
				for (int i=0; i<nChannels; ++i) {
					dAvgFluorStDeviation[i][j] = 0;				// Assyl
				}
				
				nFluorPixels[j] = 0;
			}*/
			computeMixingMatrix();
		}

		public void clearBackground(int channel) {
			if (channel<0 || channel>=nChannels)
				throw new IllegalArgumentException("Channel out of range: "+channel);
			dAvgBackground[channel] = 0;
			nBackgroundPixels[channel] = 0;
			computeMixingMatrix();
		}

		public void clearFluor(int fluor) {
			if (fluor<0 || fluor>=nFluors)
				throw new IllegalArgumentException("Fluor out of range: "+fluor);
			for (int i=0; i<nChannels; i++) {
				dAvgFluorSignal[i][fluor] = 0;
			}
			/*for (int i=0; i<nChannels; i++) {
				dAvgFluorStDeviation[i][fluor] = 0;				// Assyl
			}*/
			nFluorPixels[fluor] = 0;
			computeMixingMatrix();
		}

		/** Add a measurement of the background intensity for channel "channel". 
		 *  Parameters: mean background intensity, number of Pixels, which have been measured. */
		public void addBackgroundMeasure(int channel, double meanValue, long nPixels) {
			if (channel<0 || channel>=nChannels)
				throw new IllegalArgumentException("Channel out of range: "+channel);
			if (meanValue < 0)
				throw new IllegalArgumentException("Invalid measurement: "+IJ.d2s(meanValue));
			if (nPixels <= 0)
				throw new IllegalArgumentException("Invalid number of pixels: "+IJ.d2s(nPixels));
				
			long sumNPixels = nBackgroundPixels[channel]+nPixels;
			double f1 = ((double)nBackgroundPixels[channel]) / ((double)sumNPixels);
			double f2 = ((double)nPixels) / ((double)sumNPixels);

			dAvgBackground[channel] = dAvgBackground[channel] * f1 + meanValue * f2;
			nBackgroundPixels[channel] = sumNPixels;

			computeMixingMatrix();
		}

		/** Add a measurement of the fluorochrome distribution for fluor "fluor". 
		 * Parameters: 
		 * Array with mean intensities of fluor "fluor" in all channels (meanValues[]), 
		 * number of pixels, which have been measured (nPixels, same for all channels). */
		public void addFluorMeasure(int fluor, double meanValues[],/* double sdValues[],*/ long nPixels) {

			if (fluor<0 || fluor>=nFluors)
				throw new IllegalArgumentException("Fluor out of range: "+fluor);
			if (meanValues.length != nChannels)
				throw new IllegalArgumentException("Wrong number of channels "+meanValues.length);
			if (nPixels <= 0)
				throw new IllegalArgumentException("Invalid number of pixels: "+IJ.d2s(nPixels));
			
			long sumNPixels = nFluorPixels[fluor]+nPixels;
			double f1 = ((double)nFluorPixels[fluor]) / ((double)sumNPixels);
			double f2 = ((double)nPixels) / ((double)sumNPixels);

			for (int i=0; i<nChannels; i++) {
				dAvgFluorSignal[i][fluor] = dAvgFluorSignal[i][fluor] * f1 + meanValues[i] * f2;
			}
			// Asyl standard deviation
			/*for (int i=0; i<nChannels; i++) {
				dAvgFluorStDeviation[i][fluor] = dAvgFluorStDeviation[i][fluor] * f1 + sdValues[i] * f2;
			}*/
			
			nFluorPixels[fluor] = sumNPixels;
			
			computeMixingMatrix();			
		}


		/** Returns the number of channels. */
		public int getNChannels() {
			return nChannels;
		}
		/** Returns the number of fluorochromes. */
		public int getNFluors() {
			return nFluors;
		}
		
		public void setFluorName(int fluor, String name) {
			if (fluor<0 || fluor>=nFluors)
				throw new IllegalArgumentException("Fluor out of range: "+fluor);
			sFluorNames[fluor] = name;
		}

		public void setChannelName(int channel, String name) {
			if (channel<0 || channel>=nChannels)
				throw new IllegalArgumentException("Channel out of range: "+channel);
			sChannelNames[channel] = name;
		}


		public double getMixingMatrixEntry(int channel, int fluor) {
			if (channel<0 || channel>=nChannels)
				throw new IllegalArgumentException("Channel out of range: "+channel);
			if (fluor<0 || fluor>=nFluors)
				throw new IllegalArgumentException("Fluor out of range: "+fluor);

			return dMixingMatrix[channel][fluor];
		}
		
		public double getInverseMatrixEntry(int fluor, int channel) {
			if (channel<0 || channel>=nChannels)
				throw new IllegalArgumentException("Channel out of range: "+channel);
			if (fluor<0 || fluor>=nFluors)
				throw new IllegalArgumentException("Fluor out of range: "+fluor);

			return dInverseMatrix[fluor][channel];
		}

		/** Matrix is valid: all necessary entries have been measured. */
		public boolean matrixValid() {
			return matrixValid;			
		}

		/** Inverse is valid: Matrix valid and Rank = nFluors. */
		public boolean inverseValid() {
			return inverseValid;			
		}
		
		/** Check, whether the table already contains at least one measurement */
		public boolean containsData() {
			boolean containsData = false;
			for (int i=0; i<nChannels; i++) {
				if (nBackgroundPixels[i] != 0) {
					containsData = true;
					break;
				}
			}
			for (int j=0; j<nFluors; j++) {
				if (nFluorPixels[j] != 0) {
					containsData = true;
					break;
				}	
			}
			return containsData;
		}
		
		public double getFluorSignal(int channel, int fluor) {
			if (channel<0 || channel>=nChannels)
				throw new IllegalArgumentException("Channel out of range: "+channel);
			if (fluor<0 || fluor>=nFluors)
				throw new IllegalArgumentException("Fluor out of range: "+fluor);
			return dAvgFluorSignal[channel][fluor];
		}
		
		// Standard deviation values return 			Assyl
		/*public double getFluorStDeviation(int channel, int fluor) {
			if (channel<0 || channel>=nChannels)
				throw new IllegalArgumentException("Channel out of range: "+channel);
			if (fluor<0 || fluor>=nFluors)
				throw new IllegalArgumentException("Fluor out of range: "+fluor);
			return dAvgFluorStDeviation[channel][fluor];
		}*/
				
		public long getNFluorPixels(int fluor) {
			if (fluor<0 || fluor>=nFluors)
				throw new IllegalArgumentException("Fluor out of range: "+fluor);			
			return nFluorPixels[fluor];
		}

		public double getBackgroundSignal(int channel) {
			if (channel<0 || channel>=nChannels)
				throw new IllegalArgumentException("Channel out of range: "+channel);
			return dAvgBackground[channel];
		}
		
		public long getNBackgroundPixels(int channel) {
			if (channel<0 || channel>=nChannels)
				throw new IllegalArgumentException("Channel out of range: "+channel);			
			return nBackgroundPixels[channel];
		}


		public String getFluorName(int fluor) {
			if (fluor<0 || fluor>=nFluors)
				throw new IllegalArgumentException("Fluor out of range: "+fluor);
			return sFluorNames[fluor];
		}

		public String getChannelName(int channel) {
			if (channel<0 || channel>=nChannels)
				throw new IllegalArgumentException("Channel out of range: "+channel);
			return sChannelNames[channel];
		}
		
		public void saveAs(String path) throws IOException {
			PrintWriter pw = null;
			try {
				FileOutputStream fos = new FileOutputStream(path);
				BufferedOutputStream bos = new BufferedOutputStream(fos);
				pw = new PrintWriter(bos);
			}
			catch (IOException e) {
				throw new IOException("Error in writing MixingMatrix: "+e.getMessage());
			}

			pw.print(TAG_N_CHANNELS+"\t");
			pw.println(nChannels);
			
			pw.print(TAG_N_FLUORS+"\t");
			pw.println(nFluors);
			
			pw.print(TAG_MIXING_MATRIX_VALID+"\t");
			if (matrixValid){
				pw.println("yes");
			} else {
				pw.println("no");							
			}
			
			pw.print(TAG_INVERSE_MATRIX_VALID+"\t");
			if (inverseValid){
				pw.println("yes");
			} else {
				pw.println("no");							
			}
			
			pw.println("");
			
			pw.print(TAG_CHANNEL_NAMES);
			for (int i=0; i<nChannels; i++) {
				pw.print("\t"+getChannelName(i));    	
			}
			pw.println("");
			
			pw.print(TAG_FLUOR_NAMES);
			for (int i=0; i<nFluors; i++) {
				pw.print("\t"+getFluorName(i));    	
			}
			pw.println("");
			pw.println("");
		
			for (int i=0; i<nChannels; i++) {
				pw.print(TAG_MEASUREMENT_BACKGROUND+"\t");
				pw.print(i);
				pw.print("\t");
				pw.print(getBackgroundSignal(i));
				pw.print("\t");
				pw.print(getNBackgroundPixels(i));
				pw.println("");
			}	
			pw.println("");
					
			for (int j=0; j<nFluors; j++) {				
				pw.print(TAG_MEASUREMENT_FLUOR+"\t");
				pw.print(j);
				for (int i=0; i<nChannels; i++) {
					pw.print("\t");
					pw.print(getFluorSignal(i, j));	
				}
				pw.print("\t");
				pw.print(getNFluorPixels(j));
				pw.println("");
			}		
			pw.println("");
			
			if (matrixValid){
				for (int j=0; j<nFluors; j++) {
					pw.print(TAG_MIXING_MATRIX_FLUOR+"\t");
					pw.print(j);
					for (int i=0; i<nChannels; i++) {
						pw.print("\t");
						pw.print(getMixingMatrixEntry(i, j));	
					}
					pw.println("");
				}	
				pw.println("");
			}
			
			if (inverseValid) {	
				for (int i=0; i<nFluors; i++) {
					pw.print(TAG_INVERSE_MATRIX_FLUOR+"\t");
					pw.print(i);
					for (int j=0; j<nChannels; j++) {
						pw.print("\t");
						pw.print(getInverseMatrixEntry(i, j));	
					}
					pw.println("");
				}
			}

			if (pw.checkError()) throw(new IOException("Error in writing MixingMatrix."));
			pw.close();
		}	
			
/*		public void addFile(String path) throws IOException {
			
			
		}*/	
		
		/** Loads a dataset from disk into the current table replacing old data. 
		 * If (add==true): adds the data to the present data.*/	
		public void loadFile(String path, boolean add) throws IOException {
			int nLoadChannels = 0;
			int nLoadFluors = 0;
			
			BufferedReader br = null;
			StringTokenizer tok = null;
			String str = null, tag = null;
			
			// Read nChannels and nFluors of data file and compare to present data
			try {
				br = new BufferedReader(new FileReader(path));
				while(true) {
					str = br.readLine();
					if (str==null) break;				
					try {						
						tok = new StringTokenizer(str, "\t", false);
  						tag = tok.nextToken();
  						
						if (tag.equals(TAG_N_CHANNELS))
							nLoadChannels = Integer.parseInt(tok.nextToken());
						else if (tag.equals(TAG_N_FLUORS))
							nLoadFluors = Integer.parseInt(tok.nextToken());
							
					} catch (NoSuchElementException e){
					}
				}
				br.close();
			}
			catch (IOException e) {
				throw new IOException("Error in loading MixingMatrix: "+e.getMessage());
			}
			if (nLoadChannels != nChannels || nLoadFluors != nFluors) {
				throw new IOException("Error in loading MixingMatrix: Data dimensions do not match.");
			}
			
			// Read data into temporary results table.
			MCMResultsTable tempTab = new MCMResultsTable(nChannels, nFluors);
			try {
				br = new BufferedReader(new FileReader(path));
				boolean loop = true;
				while(loop) {
					str = br.readLine();
					if (str==null) break;				
					try {						
						tok = new StringTokenizer(str, "\t", false);
						tag = tok.nextToken();
						
						if (tag.equals(TAG_CHANNEL_NAMES)) {
							if (tok.countTokens() != nChannels) continue;
							for (int i=0; i<nChannels; ++i) {
								tempTab.setChannelName(i, tok.nextToken());
							}
						} else if (tag.equals(TAG_FLUOR_NAMES)) {
							if (tok.countTokens() != nFluors) continue;
							for (int i=0; i<nFluors; ++i) {
								tempTab.setFluorName(i, tok.nextToken());
							}
						} else if (tag.equals(TAG_MEASUREMENT_BACKGROUND)) {
							if (tok.countTokens() != 3) continue;							
							int ch = Integer.parseInt(tok.nextToken());
							double mean = Double.parseDouble(tok.nextToken());
							long num = Long.parseLong(tok.nextToken());							
							if (ch<0 || ch>=nChannels || num<=0) continue;
							tempTab.addBackgroundMeasure(ch, mean, num);
							
						} else if (tag.equals(TAG_MEASUREMENT_FLUOR)) {
							if (tok.countTokens() != nLoadChannels+2) continue;
							int fl = Integer.parseInt(tok.nextToken());
							double[] means = new double[nLoadChannels];
							//double[] stdev = new double[nLoadChannels];	//Assyl
							for (int i=0; i<nLoadChannels; ++i) {
								means[i] = Double.parseDouble(tok.nextToken());
							}
							/*for (int i=0; i<nLoadChannels; ++i) {				// standard deviation Asyl
								stdev[i] = Double.parseDouble(tok.nextToken());
							}*/
							long num = Long.parseLong(tok.nextToken());					
							if (fl<0 || fl>=nFluors || num<=0) continue;
							tempTab.addFluorMeasure(fl, means, /*stdev,*/ num);
						}
						
					} catch (NoSuchElementException e){
					}
				}
				br.close();
			}
			catch (IOException e) {
				throw new IOException("Error in loading MixingMatrix: "+e.getMessage());
			}

			// Copy data from temporary table to this table.
			// Clear table and copy names.
			if (!add) {
				clear();
				for(int i=0; i<nChannels; ++i) {
					setChannelName(i, tempTab.getChannelName(i));
				}
				for(int j=0; j<nFluors; ++j) {
					setFluorName(j, tempTab.getFluorName(j));
				}
			}			
			// Copy data
			for(int i=0; i<nChannels; ++i) {
				if(tempTab.getNBackgroundPixels(i)>0)
					addBackgroundMeasure(i, tempTab.getBackgroundSignal(i), tempTab.getNBackgroundPixels(i));
			}
			for(int j=0; j<nFluors; ++j) {
				if(tempTab.getNFluorPixels(j)>0) {
					double[] means = new double[nChannels];
					//double[] stdev = new double[nChannels];	// Assyl
					for (int i=0; i<nChannels; ++i) {
						means[i] = tempTab.getFluorSignal(i, j);
					}
					/*for (int i=0; i<nChannels; ++i) {
						stdev[i] = tempTab.getFluorStDeviation(i, j);		//Assyl
					}*/
					addFluorMeasure(j, means, /*stdev,*/ tempTab.getNFluorPixels(j)); 
				}						
			}			
			tempTab = null;
		} // end of loadFile


		private void initDataStructures() {
			matrixValid = false;
			inverseValid = false;
			sChannelNames = new String[nChannels];
			sFluorNames = new String[nFluors];
			dAvgBackground = new double[nChannels];
			nBackgroundPixels = new long[nChannels];
			dAvgFluorSignal = new double[nChannels][nFluors];
			//dAvgFluorStDeviation = new double[nChannels][nFluors];   // Standard deviation Assyl
			nFluorPixels = new long[nFluors];
			dMixingMatrix = new double[nChannels][nFluors];
			dInverseMatrix = new double[nFluors][nChannels];

			for (int i=0; i<nFluors; i++) {
				sFluorNames[i] = new String("Fluor "+(i+1));
			}
			for (int i=0; i<nChannels; i++) {
				sChannelNames[i] = new String("Ch "+(i+1));
			}			
		}

		
		private void computeMixingMatrix() {
			// check, whether one of the measurements is empty
			boolean valid = true;
			for (int c=0; c<nChannels; ++c) {
				if (nBackgroundPixels[c] == 0) {
					valid = false;
					break;
				}
			}
			for (int f=0; f<nFluors; ++f) {
				if (nFluorPixels[f] == 0) {
					valid = false;
					break;
				}	
			}
			
			// set global valid flag
			matrixValid = valid;

			// compute mixing matrix or fill with zeros
			if (valid) {
				for (int f=0; f<nFluors; ++f) {
					// compute total signal minus background for the Fluor
					double fluorTotal = 0;
					for (int c=0; c<nChannels; ++c) {
						dMixingMatrix[c][f] = dAvgFluorSignal[c][f] - dAvgBackground[c];
						fluorTotal += dMixingMatrix[c][f];
					}
					// compute MixingMatrix entry
					for (int c=0; c<nChannels; ++c) {
						dMixingMatrix[c][f] /= fluorTotal;
					}										
				}
			// fill matrix with zeros
			} else {
				for (int c=0; c<nChannels; ++c) {
					for (int f=0; f<nFluors; ++f) {
						dMixingMatrix[c][f] = 0;
					}
				}							
			}
			
			// compute inverse or pseudoinverse of mixing matrix
			if (valid) {
				Matrix MixingMatrix = new Matrix(dMixingMatrix);
				if (MixingMatrix.rank() >= nFluors) {
					dInverseMatrix = MixingMatrix.inverse().getArray();
					inverseValid = true;
				} else {
					inverseValid = false;
				}			
			} else {
				for (int f=0; f<nFluors; ++f) {
					for (int c=0; c<nChannels; ++c) {
						dInverseMatrix[f][c] = 0;
					}
				}
				inverseValid = false;
			}
			
		} // end of computeMixingMatrix()

    } // end of class MCMResultsTable