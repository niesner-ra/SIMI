import ij.*;
import ij.io.*;
import ij.gui.*;
import ij.process.*;
import ij.plugin.frame.*;

import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

/*
 * Created on 08.01.2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */


/**
 * @author Joachim Walter
 *
 */
public class Unmix_ extends PlugInFrame implements SpectralUnmixing, ActionListener {

	TextField textFilename;
	Button bLoad;
	Button bUnmix;
	Button bFingerprint;		// Assyl
	Button bQuit;
	Checkbox chOut32Bit;
	
	Label lData;
	
	static final String MSG_NO_DATA = "No matrix file loaded.";
	
	private int nChannels;
	private int nFluors;
	
	private String[] sChannelNames;
	private String[] sFluorNames;
	
	private float[] fAvgBackground;
	private float[][] fInverseMatrix; // inverse or pseudoinverse of mixing matrix
	private float[][] fMixingMatrix; // Assyl
	private float[][] differenceMatrix; // Assyl
	private boolean inverseValid;	
	private boolean matrixValid;		// Assyl

	private File file;

	// constants and variables for making the plugin macro scriptable
	private static final String cmdName = "Unmix ";
	private static final String openDialogTitle = "Open Matrix File";
	private static final String ch32bitTitle = "32-bit float output";
	private static final String similarityOn = "similarity";
	private static final String linearOn = "linear";
	private boolean wroteMacroCmd;
	private String macroOptions;

	
	public Unmix_ (){
		super("Unmix Channels  "+SpectralUnmixing.VERSIONSTRING);
		setLayout(new GridLayout(3,1));
		
		Panel pFile = new Panel(new FlowLayout(FlowLayout.LEFT, 2, 0));		
		bLoad = new Button("Load");
		bLoad.addActionListener(this);
		pFile.add(bLoad);
		textFilename = new TextField(40);
		textFilename.addActionListener(this);
		pFile.add(textFilename);
		this.add(pFile);
		
		lData = new Label(MSG_NO_DATA);
		this.add(lData);

		Panel pFunc = new Panel(new BorderLayout(20,0));
		bUnmix = new Button("Linear Unmix");
		bUnmix.addActionListener(this);
		pFunc.add(bUnmix, BorderLayout.WEST);
		
		// Fingerprint button		Assyl
		bFingerprint = new Button("Similarity Unmix");
		bFingerprint.addActionListener(this);
		pFunc.add(bFingerprint, BorderLayout.SOUTH); 

		chOut32Bit = new Checkbox(ch32bitTitle, false);
		pFunc.add(chOut32Bit, BorderLayout.CENTER);	
		
		bQuit = new Button("Quit");
		bQuit.addActionListener(this);
		pFunc.add(bQuit, BorderLayout.EAST);	
		this.add(pFunc);
		
		pack();
		setResizable(false);	
		
		file = null;
	}

	
	public void run(String arg) {	
		WindowManager.addWindow(this);
		show();
		
		wroteMacroCmd = false;
		inverseValid = false;
		
		// Do not record here, but in unmix() or close()
		if (Recorder.record) {
			Recorder.setCommand(null);
		}
		
		// Do this, if plugin is called from a macro.
		macroOptions = Macro.getOptions();
		if (macroOptions != null) {
			bLoad.setEnabled(false);
			bUnmix.setEnabled(false);
			bFingerprint.setEnabled(false);		// Assyl fingerprint
			bQuit.setEnabled(false);
			textFilename.setEnabled(false);			
			if (macroOptions.indexOf(Macro.trimKey(ch32bitTitle)+" ") >= 0) {
				chOut32Bit.setState(true);
			}			
			chOut32Bit.setEnabled(false);
			loadFile(true);
			CharSequence cs1 ="similarity";
			CharSequence cs2 ="linear";
			if(macroOptions.contains(cs1)){
				fingerprint();
			} else if(macroOptions.contains(cs2)){
				unmix();
			}
			close();		
		}
		
	}


	public void loadFile(boolean showDialog) {
		int nLoadChannels = 0;
		int nLoadFluors = 0;
		
		BufferedReader br = null;
		StringTokenizer tok = null;
		String str = null, tag = null;

		// Get filename from TextField or from dialog.
		String filename = textFilename.getText();
		File tmpFile = new File(filename);
		if (macroOptions != null) {
			filename = Macro.getValue(Macro.getOptions(), openDialogTitle, "");	
			tmpFile = new File(filename);	
			if(!tmpFile.exists() || !tmpFile.isFile()) {	
				IJ.showMessage("Error", "Invalid matrix file in macro.");
				close();
				return;
			}			
		}
		if (!tmpFile.exists() || !tmpFile.isFile() || showDialog ) {
			OpenDialog od = new OpenDialog(openDialogTitle, "");
			if (od.getFileName() == null) return;
			filename = od.getDirectory()+od.getFileName();
			tmpFile = new File(filename);
			if(!tmpFile.exists() || !tmpFile.isFile() ) return;
		}	
		
		// Read nChannels and nFluors from data file and compare to present data.
		try {
			br = new BufferedReader(new FileReader(filename));
			while(true) {
				str = br.readLine();
				if (str==null) break;				
				try {						
					tok = new StringTokenizer(str, "\t", false);
						tag = tok.nextToken();
						
					if (tag.equals(TAG_N_CHANNELS))
						nLoadChannels = Integer.parseInt(tok.nextToken());
					else if (tag.equals(TAG_N_FLUORS))
						nLoadFluors = Integer.parseInt(tok.nextToken());
						
				} catch (NoSuchElementException e){
				}
			}
			br.close();
		}
		catch (IOException e) {
			return;
		}			
		if(nLoadFluors<=0 || nLoadChannels<=0 /*|| nLoadFluors>nLoadChannels*/) {		// restriction changed cause of Similarity feature: it works even if nLoadChannels<nLoadFluors  - Assyl
			return; 
		} 
						
		// File accepted as data file: display parameters.
		file = tmpFile;
		inverseValid = true;
		matrixValid = true;		// Assyl
		textFilename.setText(filename);
		nFluors = nLoadFluors;
		nChannels = nLoadChannels;
		lData.setText(file.getName()+"   "+nFluors+" Fluors  "+nChannels+" Channels");
		sFluorNames = new String[nFluors];
	
		// Read entries of inverse (unmixing) matrix and fluorochrome names from text file.
		fInverseMatrix = new float[nFluors][nChannels];
		fMixingMatrix = new float[nFluors][nChannels];
		fAvgBackground = new float[nChannels];
		try {
			br = new BufferedReader(new FileReader(filename));
			while(true) {
				str = br.readLine();
				if (str==null) break;				
				try {						
					tok = new StringTokenizer(str, "\t", false);
						tag = tok.nextToken();
						if (tag.equals(TAG_INVERSE_MATRIX_FLUOR)) {
							if (tok.countTokens() != nChannels+1) continue;
							int fl = Integer.parseInt(tok.nextToken());
							if (fl<0 || fl>=nFluors) continue;
							
							for (int i=0; i<nChannels; ++i) {
								fInverseMatrix[fl][i] = Float.parseFloat(tok.nextToken());
							}				
							
						} else if (tag.equals(TAG_MIXING_MATRIX_FLUOR)) {				// Assyl
							if (tok.countTokens() != nChannels+1) continue;
							int fl = Integer.parseInt(tok.nextToken());
							if (fl<0 || fl>=nFluors) continue;
							
							for (int i=0; i<nChannels; ++i) {
								fMixingMatrix[fl][i] = Float.parseFloat(tok.nextToken());
							}				
							
						} else if (tag.equals(TAG_FLUOR_NAMES)) {
							if (tok.countTokens() != nFluors) continue;
							for (int i=0; i<nFluors; ++i) {
								sFluorNames[i] = tok.nextToken();
							}
							
						} else if (tag.equals(TAG_MEASUREMENT_BACKGROUND)) {
							if (tok.countTokens() != 3) continue;							
							int ch = Integer.parseInt(tok.nextToken());
							float value = Float.parseFloat(tok.nextToken());
							long num = Long.parseLong(tok.nextToken());							
							if (ch<0 || ch>=nChannels || num<=0) continue;
							fAvgBackground[ch] = value;
						}						
				} catch (NoSuchElementException e){
				}
			}
			br.close();
		}
		catch (IOException e) {
			return;
		}
	} 

	// Fingerprinting algorithm		Assyl
	public void fingerprint() {
		boolean b32BitOut = chOut32Bit.getState();
				
		differenceMatrix = new float[nChannels][nFluors]; // initialization of matrix difference
		
		if (!matrixValid || nFluors<=0 || nChannels <= 0) {
			IJ.error("invalid fingerprinting matrix");
			return; 
		}
		
		ImagePlus[] chVector = new ImagePlus[nChannels];
		
		ImageProcessor[] chIPVector = new ImageProcessor[nChannels];
		ImagePlus[] duplChVector = new ImagePlus[nChannels];	// dublicate Image Plus of chIPVector for all channels normalization procedure
		ImageProcessor[] duplChIPVector = new ImageProcessor[nChannels];
		int[] currentSlice = new int[nChannels];
		
		// Get list of open images from WindowManager.
		int[] idList = WindowManager.getIDList();
		int nWindows = WindowManager.getWindowCount();
		String[] titleList = new String[nWindows];
		for (int i=0; i<nWindows; ++i) {
			titleList[i] = WindowManager.getImage(idList[i]).getTitle();
		}
		
		if(Recorder.record) {
			Recorder.setCommand(cmdName);
		}
		
		// Select images as channels in dialog.
				GenericDialog gd = new GenericDialog("Select Channels", this);
				int j = 0;		
				for (int i=0; i<nChannels; ++i) {
					if(i<nWindows) j=i;
					gd.addChoice("Ch_"+(i+1), titleList, titleList[j]);
				}
				gd.showDialog();
				
				if(gd.wasCanceled()) {
					if(Recorder.record) {
						Recorder.setCommand(null);
					}
					return; 
				}
		
				// Get image and dimensions of first channel. 
				// Return error, if type is RGB or indexed.
				int width=0, height=0, stackSize=0;
				int imageType;
				try{
					chVector[0] = WindowManager.getImage(idList[gd.getNextChoiceIndex()]);
					chIPVector[0] = chVector[0].getProcessor();
					duplChVector[0]  = chVector[0].duplicate();		// dublicate Image Plus of chIPVector for all channels normalization procedure
					duplChIPVector[0] = duplChVector[0].getProcessor();				
					currentSlice[0] = chVector[0].getCurrentSlice();
					width = chVector[0].getWidth();
					height = chVector[0].getHeight();
					stackSize = chVector[0].getStackSize();
					imageType = chVector[0].getType();
					if (imageType == ImagePlus.COLOR_RGB || imageType == ImagePlus.COLOR_256) {
						IJ.error("Channels cannot be RGB or indexed Color.");
						return;
					}
					
					// Get images and dimensions of other channels.
					for(int i=1; i<nChannels; ++i) {
						chVector[i] = WindowManager.getImage(idList[gd.getNextChoiceIndex()]);
						chIPVector[i] = chVector[i].getProcessor();
						duplChVector[i]  = chVector[i].duplicate();		// dublicate Image Processor of chIPVector for all channels normalization procedure
						duplChIPVector[i] = duplChVector[i].getProcessor();
						currentSlice[i] = chVector[i].getCurrentSlice();
						if (chVector[i].getType() == ImagePlus.COLOR_RGB || imageType == ImagePlus.COLOR_256) {
							IJ.error("Channels cannot be RGB or indexed Color.");
							return;
						}
						if(chVector[i].getWidth() != width ||
							chVector[i].getHeight() != height ||
							chVector[i].getStackSize()!=stackSize) {
								
							IJ.error("All channels must have the same dimensions.");
							return;
						}			
					}	 
				} catch (RuntimeException e) {
					close();
					return;
				}
				
				// Add 32-bit option and matrix file name to macro options.
				
				if(Recorder.record) {
					if (b32BitOut) {
						Recorder.recordOption(ch32bitTitle);
					}
										
					Recorder.recordOption(similarityOn);		// add also similarity status, Assyl
					
					Recorder.recordPath(openDialogTitle, file.getAbsolutePath());
					Recorder.saveCommand();
					wroteMacroCmd = true;
				}	
				
			// Create images for unmixed fluorochrome signals.		
			ImagePlus[] fluoVector = new ImagePlus[nFluors];
			ImageProcessor[] fluoIPVector = new ImageProcessor[nFluors];
			
			for(int i=0; i<nFluors; ++i) {
				fluoVector[i] = NewImage.createFloatImage(sFluorNames[i], width, height, stackSize, NewImage.FILL_BLACK);
				fluoVector[i].show();
				fluoIPVector[i] = fluoVector[i].getProcessor();
			}
			 
			// Apply fingerprinting to every pixel.		Assyl
			boolean chPixelsIsBackground = false, allChCorrFluorEqual = false; //allChSimilarityEqual=false;
			int x,y,z, f,c;
			float value, background=0, RestBackground, sumLS; // sumLS - sum of least squared elements/brackets  
			float[] chPixels = new float[nChannels];
			float[] LSarray = new float[nFluors];	 // Assyl  least squared array
			/*
			// ========================= Pixel values normalization of all channels  - Assyl
			for(z=1; z<=stackSize; ++z) {
				for(c=0; c<nChannels; ++c) {
					duplChVector[c].setSlice(z);
				}
				for(f=0; f<nFluors; ++f) {
					fluoVector[f].setSlice(z);
				}
				
				double maxPixelValue = 0, maxPixelValue2 = 0;
				double t=0;
				for(c=0; c<nChannels; c++) {
					maxPixelValue = (float) duplChIPVector[c].getMax();
					maxPixelValue2 = duplChIPVector[c].getPixelValue(0, 0);
					for(x=0; x<width; ++x) {
						for(y=0; y<height; ++y) {
							if(maxPixelValue2 < duplChIPVector[c].getPixel(x, y)) {
								maxPixelValue2 = duplChIPVector[c].getPixel(x, y);
							}
						}
					}
				// All channels normalization - Normalizing the pixel value chPixels[] 	over all channels  	Assyl
					
						for(x=0; x<width; ++x) {
							for(y=0; y<height; ++y) {
								if(duplChIPVector[c].getPixel(x, y)<fAvgBackground[c]) {
									t=0;
								} else{
									t = 1000*(duplChIPVector[c].getPixel(x, y) - fAvgBackground[c])/(maxPixelValue2 - fAvgBackground[c]);
								}
								duplChIPVector[c].putPixelValue(x, y, t);
							}
						}
				}
				
					//================
					for(c=0; c<nChannels; ++c) {
						//duplChVector[c] = NewImage.createFloatImage(sChannelNames[c], width, height, stackSize, NewImage.FILL_BLACK);
						duplChVector[c].show();
						duplChVector[c].getProcessor().resetMinAndMax();
						duplChVector[c].updateAndRepaintWindow(); 
					}
					//================
			} */ //================ end normalizaton ===================
			
			// Loop over slices.
			for(z=1; z<=stackSize; ++z) {
				for(c=0; c<nChannels; ++c) {
					chVector[c].setSlice(z);
				}
				for(f=0; f<nFluors; ++f) {
					fluoVector[f].setSlice(z);
				}
				
				for(x=0; x<width; ++x) {
					for(y=0; y<height; ++y) {
						
						//======= this part of two loops needs for background check 
						for(c=0; c<nChannels; ++c) {
							chPixels[c] = (chIPVector[c].getPixelValue(x, y) - fAvgBackground[c])/fAvgBackground[c];
						}	
						
						//============================================
				 
						for(c=0;c<nChannels; ++c) {							// check for background pixels; 
					 if(Math.abs(chPixels[c]) < 0.005) {		// 
						 chPixelsIsBackground = true;
					 } else{
						 chPixelsIsBackground = false;
						 break;
					 }
				 }
						
						if(chPixelsIsBackground)	{					 
							for(f=0; f<nFluors; ++f) {					 
								background = 0; // chIPVector[c].getPixelValue(x,y); corrected 07Oct16 	 
								fluoIPVector[f].putPixelValue(x, y, background);
							}
						} else {								// condition for other pixels containing signal
							
							// Read pixel values from IPs to channel vector 
							// and subtract background.
						
						//	step which is repeating the loop for background check   
						float chPixelsTotal = 0;
						int minFluor;
						for(c=0; c<nChannels; ++c) {
							if(chIPVector[c].getPixelValue(x, y) <= fAvgBackground[c]) {  	// condition to avoid negative values 
								chPixels[c] = 0; 											// in chPixels[] after subtracting
							} else {
								chPixels[c] = chIPVector[c].getPixelValue(x, y) - fAvgBackground[c];
								chPixelsTotal += chPixels[c];
							}
						}	
						// Normalizing the pixel value chPixels[] 	over all channels  	Assyl
						for(c=0; c<nChannels; ++c) {
							chPixels[c] /= chPixelsTotal;
						}
						
						//==================================== - Begin - min procedure - least squared fit - =================
							
						 for(f=0; f<nFluors; ++f) {
								sumLS = 0; 
								LSarray[f] = 0;
								for(c=0; c<nChannels; ++c) {
									LSarray[f] = (chPixels[c] - fMixingMatrix[f][c])*(chPixels[c] - fMixingMatrix[f][c]);  
									sumLS += LSarray[f]; 
								} 																
								LSarray[f] = sumLS;
							}
						minFluor = 0;
						float min = LSarray[0];
						for(f=1; f<nFluors; ++f) {
							if(LSarray[f] < min) {
								min = LSarray[f];
								minFluor = f;
							}
						}
						
						float maxValue;											// find the max pixel value among all channels and 
						int q = 0;
						maxValue = chIPVector[q].getPixelValue(x,y);			// put this value in the  pixel of those fluors found by ls fit  (07Oct16)
						for(c=1; c<nChannels; ++c){
							if(chIPVector[c].getPixelValue(x,y) > maxValue){
								maxValue = chIPVector[c].getPixelValue(x,y);
								q=c;
							}
						}
						//value = chIPVector[minFluor].getPixelValue(x,y)-fAvgBackground[minFluor];		// 01Nov16, value for conventional case, when only Nch>=Nfl
						value = maxValue - fAvgBackground[q];											// 07Oct16, value for simi advance case, when Nch can be < Nfl
						fluoIPVector[minFluor].putPixelValue(x, y, value);		
						
						for(f=0; f<nFluors; f++) {
							if(f!= minFluor) {
								RestBackground = 0; 					  //background for 07Oct16, value for simi advance case, when Nch can be < Nfl
								//RestBackground = fAvgBackground[f];		  //background for 01Nov16, value for conventional case, when only Nch>=Nfl
								fluoIPVector[f].putPixelValue(x, y, RestBackground);
							}
						}
						//============================================== - End - min procedure - least squared fit ==============
						/*
						//==================================== - Begin - min procedure - channel by channel ==================
													
						// Assyl
						// Do comparison the "mixing" matrix elements, which contain fingerprints of distinct 
						// flurophores, with the elements of the flurochrome mixture at different channels.
						 for(f=0; f<nFluors; ++f) {
							//value  = fInverseMatrix[f][0] * chPixels[0];
							for(c=0; c<nChannels; ++c) {
								differenceMatrix[f][c] = chPixels[c] - fMixingMatrix[f][c];  
								differenceMatrix[f][c] = Math.abs(differenceMatrix[f][c]);	// here the element value of difference matrix is more important than the sign,  
								//value += fInverseMatrix[f][c] * chPixels[c];				// because it tells how close the pixel value chPixels[] is to fingerprints.  
							} 																// This is why Math.abs is used
							//fluoIPVector[f].putPixelValue(x, y, value);
						}
						// assigning a min difference between fingerprint's pixel value and pixel value 
						// chPixels[] of current image w/ fluorophore mixture 
						float[] diffFluorsInOneChannel = new float [nFluors]; 	// array of Fluorophores at a given channel of the fingerprint set/array, inside which min will be defined 
						int[] chCorrelateFluor = new int [nChannels]; 
						int[] flQuantChannels = new int [nFluors]; 
						int minFluor, maxFluor; 	// marker for closest fingerprint to current fluorophore
						for(c=0; c<nChannels; c++) {
							for(f=0; f<nFluors; f++) {
								diffFluorsInOneChannel[f] = differenceMatrix[f][c];														
							}
							minFluor = 0;
							float min = diffFluorsInOneChannel[0];
							for(f=1; f<nFluors; f++) {
								if(diffFluorsInOneChannel[f] < min) {
									min=diffFluorsInOneChannel[f];
									minFluor = f;
								} 
							}
							// if nChannels = nFluors ==> then the pixel value of current fluorophore mixture
							// assigned to this particular fluorophore will be put into channel reference to 
							// this fluorophore, e.g. for first fluorophore - reference channel is first etc. 
							// fluorophore f = channel c !!!
							// In case, nChannels != nFluors there is an uncertainty, from which channel of the 
							// analyzing image (mixture of flurophores) the pixel 
							// values should be taken to identify the assigned fluorophore. 
							// channel = fluor!!! 
							// 6Apr16 -- there is a solution for uncertainty for case, nChannels != nFluors: 
							// the pixel value should be taken from the channel, where valus is maximum 
							
							chCorrelateFluor[c] = minFluor;		// chSimilarity[] not exist. chCorrelateFluor[] array shows correlation between channels and flurophores 
														// meaning which channel correlates/is similar to given fluorophore
							
							
							// value = chIPVector[fluor].getPixelValue(x,y);
							// fluoIPVector[fluor].putPixelValue(x, y, value);
							// RestBackground = fAvgBackground[nFluors-1-fluor]; //background;//
							// fluoIPVector[nFluors-1-fluor].putPixelValue(x, y, RestBackground); 
							// fluoVector[fluor].updateAndRepaintWindow();  
						} 
						
						
						
						for(f=0; f<nFluors; f++) {
							int t=0;
							for(c=0; c<nChannels; c++) {
								if(f==chCorrelateFluor[c]) {
									if(f==c) {			// this condition gives preference to the reference channel(1st fluor - 1st channel, 
										t = nChannels;	// 2nd fluor - 2nd channel etc. It is not defined what to do in case non-quadratic 
									} else {			// system, nFluors==nChannels
										t++;
									}
								}
							} 
							flQuantChannels[f] = t;		// index f of this array is a fluorophore, value t represents   
						}									// the number of times the given fluorophore f has been fit at all set of channels 
						
						
						//	if(chCorrelateFluor[c] == chCorrelateFluor[c+1]) {
						//		allChSimilarityEqual = true;
						//	} else {	// case when different channels are similar to different fluors. Needs to be written 
						//		break;
						//	} 
						// for(f=0; f<nFluors; f++) {	
						//	if(flQuantChannels[f] == nFluors) { // 
						//		maxFluor = f; 
						//		allChCorrFluorEqual= true;
						//		break;
						//	} 
						//  }
						
						// find a max value, max times fingerprints of a given fluorophore similar to current image chPixels[], inside array flQuantChannels[]
						maxFluor = 0;
						int max = flQuantChannels[0];
						for (f=1; f<nFluors; f++) {
							if(flQuantChannels[f] > max) {
								max = flQuantChannels[f];
								maxFluor = f;
							}
						}
						
						//if(allChCorrFluorEqual) {
						//	fluor = chCorrelateFluor[0];
						 
						
						// int p=0;
						// value = (chIPVector[p].getPixelValue(x,y)-fAvgBackground[p])/fAvgBackground[p];	// max relative value from background among all channels 
						// for(c=1; c<nChannels; c++){
						// 	if(value < (chIPVector[c].getPixelValue(x,y)-fAvgBackground[c])/fAvgBackground[c]) {
						//		value = (chIPVector[c].getPixelValue(x,y)-fAvgBackground[c])/fAvgBackground[c];
						//		p = c;
						//	}
						// } 
						// value = chIPVector[p].getPixelValue(x,y);  
						 
							value = chIPVector[maxFluor].getPixelValue(x,y);
							fluoIPVector[maxFluor].putPixelValue(x, y, value);
							for(f=0; f<nFluors; f++) {
								if(f!= maxFluor) {
									RestBackground = fAvgBackground[f]; //background;//
									fluoIPVector[f].putPixelValue(x, y, RestBackground);
								}
							}
						//========================================== - End - min procedure - channel by channel ============================================
						*/		
						//}
						
					}
				}
				if(stackSize>1) {
					IJ.showProgress(z, stackSize);
				}
				}
			}
			
			// Adapt display of fluorescence images.
			// Possibly convert back to type of first channel image. 
			int midSlice = 1;
			if(stackSize > 1) 
				midSlice = stackSize/2;
			
			ImageConverter.setDoScaling(false);
			for(f=0; f<nFluors; ++f) {
				if (!b32BitOut && imageType==ImagePlus.GRAY8) {
					if(stackSize > 1) {
						new StackConverter(fluoVector[f]).convertToGray8();
					} else {
						new ImageConverter(fluoVector[f]).convertToGray8();		
					}
					fluoVector[f].setSlice(midSlice);				
				} else if (!b32BitOut && imageType==ImagePlus.GRAY16){
					fluoVector[f].setSlice(midSlice);
					if(stackSize > 1) {
						new StackConverter(fluoVector[f]).convertToGray16();
					} else {
						new ImageConverter(fluoVector[f]).convertToGray16();
					}		
				}		
				fluoVector[f].setSlice(midSlice);
				fluoVector[f].getProcessor().resetMinAndMax();
				fluoVector[f].updateAndRepaintWindow();			
			}	
	}
	
	public void unmix() {
		boolean b32BitOut = chOut32Bit.getState();
		
		
		if (!inverseValid || nFluors<=0 || nChannels <= 0) {
			IJ.error("invalid unmixing matrix");
			return; 
		}
			
		ImagePlus[] chVector = new ImagePlus[nChannels];
		ImageProcessor[] chIPVector = new ImageProcessor[nChannels];
		int[] currentSlice = new int[nChannels];
		
		// Get list of open images from WindowManager.
		int[] idList = WindowManager.getIDList();
		int nWindows = WindowManager.getWindowCount();
		String[] titleList = new String[nWindows];
		for (int i=0; i<nWindows; ++i) {
			titleList[i] = WindowManager.getImage(idList[i]).getTitle();
		}
		
		if(Recorder.record) {
			Recorder.setCommand(cmdName);
		}
		
		// Select images as channels in dialog.
		GenericDialog gd = new GenericDialog("Select Channels", this);
		int j = 0;		
		for (int i=0; i<nChannels; ++i) {
			if(i<nWindows) j=i;
			gd.addChoice("Ch_"+(i+1), titleList, titleList[j]);
		}
		gd.showDialog();
		
		if(gd.wasCanceled()) {
			if(Recorder.record) {
				Recorder.setCommand(null);
			}
			return; 
		}
				
		// Get image and dimensions of first channel. 
		// Return error, if type is RGB or indexed.
		int width=0, height=0, stackSize=0;
		int imageType;
		try{
			chVector[0] = WindowManager.getImage(idList[gd.getNextChoiceIndex()]);
			chIPVector[0] = chVector[0].getProcessor();
			currentSlice[0] = chVector[0].getCurrentSlice();
			width = chVector[0].getWidth();
			height = chVector[0].getHeight();
			stackSize = chVector[0].getStackSize();
			imageType = chVector[0].getType();
			if (imageType == ImagePlus.COLOR_RGB || imageType == ImagePlus.COLOR_256) {
				IJ.error("Channels cannot be RGB or indexed Color.");
				return;
			}
			
			// Get images and dimensions of other channels.
			for(int i=1; i<nChannels; ++i) {
				chVector[i] = WindowManager.getImage(idList[gd.getNextChoiceIndex()]);
				chIPVector[i] = chVector[i].getProcessor();
				currentSlice[i] = chVector[i].getCurrentSlice();
				if (chVector[i].getType() == ImagePlus.COLOR_RGB || imageType == ImagePlus.COLOR_256) {
					IJ.error("Channels cannot be RGB or indexed Color.");
					return;
				}
				if(chVector[i].getWidth() != width ||
					chVector[i].getHeight() != height ||
					chVector[i].getStackSize()!=stackSize) {
						
					IJ.error("All channels must have the same dimensions.");
					return;
				}			
			}	 
		} catch (RuntimeException e) {
			close();
			return;
		}

		// Add 32-bit option and matrix file name to macro options.
		if(Recorder.record) {
			if (b32BitOut) {
				Recorder.recordOption(ch32bitTitle);
			}
									
			Recorder.recordOption(linearOn);		// similarity status false, linear unmix button pressed - linear unmixing made			
			
			Recorder.recordPath(openDialogTitle, file.getAbsolutePath());
			Recorder.saveCommand();
			wroteMacroCmd = true;
		}
		
		// Create images for unmixed fluorochrome signals.		
		ImagePlus[] fluoVector = new ImagePlus[nFluors];
		ImageProcessor[] fluoIPVector = new ImageProcessor[nFluors];		
		for(int i=0; i<nFluors; ++i) {
			fluoVector[i] = NewImage.createFloatImage(sFluorNames[i], width, height, stackSize, NewImage.FILL_BLACK);
			fluoVector[i].show();
			fluoIPVector[i] = fluoVector[i].getProcessor();
		}
		
		// Apply unmixing matrix to every pixel.
		int x,y,z, f,c;
		float value;
		float[] chPixels = new float[nChannels];
		// Loop over slices.
		for(z=1; z<=stackSize; ++z) {
			for(c=0; c<nChannels; ++c) {
				chVector[c].setSlice(z);
			}
			for(f=0; f<nFluors; ++f) {
				fluoVector[f].setSlice(z);
			}
			
			for(x=0; x<width; ++x) {
				for(y=0; y<height; ++y) {
					// Read pixel values from IPs to channel vector 
					// and subtract background.
					for(c=0; c<nChannels; ++c) {
						chPixels[c] = chIPVector[c].getPixelValue(x, y) - fAvgBackground[c];
					}	
					// Do matrix multiplication and write to fluor images.
					for(f=0; f<nFluors; ++f) {
						value  = fInverseMatrix[f][0] * chPixels[0];
						for(c=1; c<nChannels; ++c) {
							value += fInverseMatrix[f][c] * chPixels[c];
						}
						fluoIPVector[f].putPixelValue(x, y, value);
					}
				}
			}
			if(stackSize>1) {
				IJ.showProgress(z, stackSize);
			}
		}
		// Reset slices of channels to what they were before.
		for(c=0; c<nChannels; ++c) {
			chVector[c].setSlice(currentSlice[c]);
		}
		
		// Adapt display of fluorescence images.
		// Possibly convert back to type of first channel image. 
		int midSlice = 1;
		if(stackSize > 1) 
			midSlice = stackSize/2;
		
		ImageConverter.setDoScaling(false);
		for(f=0; f<nFluors; ++f) {
			if (!b32BitOut && imageType==ImagePlus.GRAY8) {
				if(stackSize > 1) {
					new StackConverter(fluoVector[f]).convertToGray8();
				} else {
					new ImageConverter(fluoVector[f]).convertToGray8();		
				}
				fluoVector[f].setSlice(midSlice);				
			} else if (!b32BitOut && imageType==ImagePlus.GRAY16){
				fluoVector[f].setSlice(midSlice);
				if(stackSize > 1) {
					new StackConverter(fluoVector[f]).convertToGray16();
				} else {
					new ImageConverter(fluoVector[f]).convertToGray16();
				}		
			}		
			fluoVector[f].setSlice(midSlice);
			fluoVector[f].getProcessor().resetMinAndMax();
			fluoVector[f].updateAndRepaintWindow();			
		}				
	}

	public void actionPerformed(ActionEvent e) {
		Object src = e.getSource();
		if(src == bQuit) {
			close();
		} else if (src == bUnmix){
			unmix();
		} else if (src == bFingerprint){
			fingerprint();
		} else if (src == bLoad){
			loadFile(true);
		} else if  (src == textFilename) {
			loadFile(false);
		}
	}
	
	public void close() {
		if (Recorder.record && !wroteMacroCmd) {
			Recorder.setCommand(cmdName);
			Recorder.saveCommand();
		}
		super.close();	
	}
}
