import ij.*;
import ij.gui.*;
import ij.io.*;
import ij.text.*;

import java.awt.*;
import java.awt.event.*;
import java.io.*;

/*
 * Created on 13.01.2004
 *
 */

/**
 * @author joachim
 */

/** TextWindow, which shows a save changes dialog, when closing is attempted, and has the "clear" and "cut"
	menu entries disabled.
	The name means MeasureChannelMatrixResultsWindow.*/
public class MCMResultsWindow extends TextWindow implements SpectralUnmixing {

	private MCMResultsTable table;			// MCMRTab object associated with this window.
	private Frame parent; // Measure_Mixing_Matrix object that produced this object.
        
	private int nChannels;
	private int nFluors;
        
	private String filePath;
	private String fileName;

	MCMResultsWindow(MCMResultsTable table, Frame parent) {
		super("Mixing Matrix  "+VERSIONSTRING, "", "", 500, 400);
		this.table = table;
		this.parent = parent;
		this.nChannels = table.getNChannels();
		this.nFluors = table.getNFluors();
		this.getMenuBar().getMenu(1).remove(3); // remove "clear" from menu
		this.getMenuBar().getMenu(1).remove(0); // remove "cut" from menu
		this.getMenuBar().getMenu(0).insert("Add", 0); // add "add" command to File Menu
		this.getMenuBar().getMenu(0).insert("Load", 0); // add "load" command to File Menu
			
		setHeadings();
		updateDataDisplay();
			
		filePath = "";
		fileName = "";
	}

	MCMResultsWindow(Frame parent) {
		super("Mixing Matrix  "+VERSIONSTRING, "", "", 500, 400);
		this.parent = parent;
		
		this.getMenuBar().getMenu(1).remove(3); // remove "clear" from menu
		this.getMenuBar().getMenu(1).remove(0); // remove "cut" from menu
		this.getMenuBar().getMenu(0).insert("Add", 0); // add "add" command to File Menu
		this.getMenuBar().getMenu(0).insert("Load", 0); // add "load" command to File Menu
		getTextPanel().setColumnHeadings("");
		updateDataDisplay();
			
		filePath = "";
		fileName = "";
	}

	public void processWindowEvent(WindowEvent e) {
		if(e.getID() == WindowEvent.WINDOW_CLOSING) {
			// Save table if present and containing data.
			if(table != null && table.containsData()) {
				SaveChangesDialog d = new SaveChangesDialog(this, "Save Measurements?");
				if (d.cancelPressed()) return;
				else if (d.savePressed()) {
					if (!saveAs("")) return;
				}
			}
			// Disconnect from parent Measure_Mixing_Matrix object, if applicable.
			if (parent !=  null && parent instanceof Measure_Mixing_Matrix) {
				Measure_Mixing_Matrix MCMparent = ((Measure_Mixing_Matrix)parent);
				if(MCMparent.isMeasuring()) 
					MCMparent.stopMeasurements();
				MCMparent.disconnectResults();
			}
		}
		super.processWindowEvent(e);
	}

	public void actionPerformed(ActionEvent e) {
		String cmd = e.getActionCommand();
		if (cmd == "Add") {
			add("");
		} else if (cmd =="Load") {
			load("");
		} else if (cmd == "Save As..."){
			saveAs("");
		} else {
			super.actionPerformed(e);
		}

	}

	public void nullParent() {
		parent = null;
	}

	/** Saves results table. Returns 'true' if saving was successful and 'false', if not.*/		
	public boolean saveAs(String path) {
		if (table==null) {
			IJ.showMessage("Error", "No results table loaded.");
			return false;
		}
		if (!table.containsData()) {
			IJ.showMessage("Error", "Results table contains no data.");
			return false;
		}
		if (path.equals("")) {			
			SaveDialog dia = new SaveDialog("Save As", filePath, ".txt");
			String name = dia.getFileName();
			if (name == null) return false; 
			path = dia.getDirectory()+name;
		}
		try {
			table.saveAs(path);
			filePath = path;
			fileName = new File(filePath).getName();
			setTitle(fileName);
		}
		catch (IOException e) {
			IJ.error(e.getMessage());
			return false;	
		}
		return true;			
	}	
					
	public void add(String path) {	
		if (table == null || !table.containsData()) {
			load(path);
			return;	
		}
		if (path.equals("")) {			
			OpenDialog dia = new OpenDialog("Add Dataset", "");
			String name = dia.getFileName();
			if (name == null) return;
			path = dia.getDirectory()+name;
		}
		try {
			table.loadFile(path, true);
			filePath = new File(new File(path).getParent(), fileName).getAbsolutePath();
		}
		catch (IOException e) {
			IJ.error(e.getMessage());
		}
			
		updateDataDisplay();		
	}	
			
	public void load(String path) {		
		if (table != null && table.containsData()) {
			if(!IJ.showMessageWithCancel("Caution!", "This will delete the existing data. Proceed?")) 
				return;
		}		
		if (path.equals("")) {			
			OpenDialog dia = new OpenDialog("Load Dataset", "");
			String name = dia.getFileName();
			if (name == null) return;
			path = dia.getDirectory()+name;
		}
		try {
			if(table == null) {
				table = new MCMResultsTable(new File(path));				
				nChannels = table.getNChannels();
				nFluors = table.getNFluors();
				setHeadings();				
			} else {
				table.loadFile(path, false);
			}
			filePath = path;
			fileName = new File(filePath).getName();
			setTitle(fileName);
		}
		catch (IOException e) {
			IJ.showMessage("Error", e.getMessage());
		}
		updateDataDisplay();			
	}
		        
	public void updateDataDisplay() {
		
		getTextPanel().selectAll();
		getTextPanel().clearSelection();

		if (table == null) {		
			append("No results table loaded.");
			return;
		}
        	
		String line;
        	
		append("# Channels\t" + Integer.toString(table.getNChannels()));
		append("# Fluors\t" + Integer.toString(table.getNFluors()));
        	
		append(" ");
        	
		line = "";
		for (int i=0; i<nChannels; i++) {
			line += "\t"+table.getChannelName(i);    	
		}
		append(line);

		line = "Mean Background";
		for (int i=0; i<nChannels; i++) {
			line += "\t"+IJ.d2s(table.getBackgroundSignal(i), 3);    	
		}			
		append(line);

		line = "#Pix Background";
		for (int i=0; i<nChannels; i++) {
			line += "\t"+Long.toString(table.getNBackgroundPixels(i), 0);    	
		}			
		append(line);
			
		append(" ");
		line = "Mean Signal 8Oct16";
		for (int i=0; i<nChannels; i++) {
			line += "\t"+table.getChannelName(i);    	
		}
		line += "\t# Pixels";
		append(line);		
			
		for (int j=0; j<nFluors; j++) {
			line = table.getFluorName(j);
			for (int i=0; i<nChannels; i++) {
				line += "\t" + IJ.d2s(table.getFluorSignal(i, j), 3);	
			}
						
			line += "\t" + Long.toString(table.getNFluorPixels(j), 0);
			append(line);
			
			/*line = "Standard deviation";	//Assyl
			for (int i=0; i<nChannels; i++) {
			line += "\t" + IJ.d2s(table.getFluorStDeviation(i, j), 3);
			}*/
			//append(line);
		}		
			
		append(" ");
			
		if (table.matrixValid()) {
			append("Mixing Matrix"); 	
			line = "";						
			for (int j=0; j<nFluors; j++) {
				line += "\t"+table.getFluorName(j);
			}
			append(line);									
			for (int i=0; i<nChannels; ++i) {
				line = table.getChannelName(i);
				for (int j=0; j<nFluors; ++j) {
					line += "\t" + IJ.d2s(table.getMixingMatrixEntry(i, j), 3);
				}	
				append(line);
			}		
		} else {
			append("Mixing Matrix invalid"); 
		}	
					
		append(" ");

		if (table.inverseValid()) {
			append("Unmixing Matrix"); 		
			line = "";	
			for (int j=0; j<nChannels; j++) {
				line += "\t"+table.getChannelName(j);
			}
			append(line);									
			for (int i=0; i<nFluors; ++i) {
				line = table.getFluorName(i);
				for (int j=0; j<nChannels; ++j) {
					line += "\t" + IJ.d2s(table.getInverseMatrixEntry(i, j), 3);
				}	
				append(line);
			}	
		} else {
			append("Unmixing Matrix invalid"); 
		}			
	}
	
	private void setHeadings() {				
		String headings = "          \t";
		for (int i=0; i<table.getNChannels(); i++){
			headings += "          \t";
		}			
		headings += "          ";
		getTextPanel().setColumnHeadings(headings);
	}

} // end of class
