/*
 * Created on 31.10.2004
 */

/**
 * @author Joachim Walter
 *
 */
public interface SpectralUnmixing {
	public static final String VERSIONSTRING = "1.3";
	
	public static final String TAG_N_CHANNELS 				= "Channels";
	public static final String TAG_N_FLUORS 				= "Fluors";
	public static final String TAG_MIXING_MATRIX_VALID 		= "MixingMatrixValid";
	public static final String TAG_INVERSE_MATRIX_VALID 	= "UnmixingMatrixValid";		
	public static final String TAG_CHANNEL_NAMES 			= "ChannelNames";
	public static final String TAG_FLUOR_NAMES 				= "FluorNames";
	public static final String TAG_MEASUREMENT_BACKGROUND 	= "MeasurementBackground";
	public static final String TAG_MEASUREMENT_FLUOR 		= "MeasurementFluor";
	public static final String TAG_MIXING_MATRIX_FLUOR 		= "MixingMatrixFluor";
	public static final String TAG_INVERSE_MATRIX_FLUOR 	= "UnmixingMatrixFluor";
}
