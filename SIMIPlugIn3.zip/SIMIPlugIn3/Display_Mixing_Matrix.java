import ij.*;
import ij.plugin.PlugIn;

/*
 * Created on 13.01.2004
 */

/**
 * @author Joachim Walter
 */
public class Display_Mixing_Matrix implements PlugIn, SpectralUnmixing {

	public void run(String arg) {		
		MCMResultsWindow resultsWindow = new MCMResultsWindow(IJ.getInstance());
		resultsWindow.setSize(500,400);
		resultsWindow.pack();
	}

}
